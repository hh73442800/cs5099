/**
 * Classes used for the management of Airport information.
 */
/**
 * @author blake
 * @version 2.0
 * @since 2017-02-10
 *
 */
package airport;