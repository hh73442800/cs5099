package airplane;

import java.util.ArrayList;

public class Airplanes extends ArrayList<Airplane> {
    private static final long serialVersionUID = 2L;


}
