package flight;

import java.util.ArrayList;

//An aggregation of trips
public class Trips extends ArrayList<Trip> {
    private static final long serialVersionUID = 4L;

}